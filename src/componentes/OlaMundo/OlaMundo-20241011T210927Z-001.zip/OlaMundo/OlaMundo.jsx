import './OlaMundo.css';

// Crie um componente chamado 'NomesOrdenados' que aceita uma prop chamado 'nomes' e deve ser uma lista com pelo menos 5 nomes de pessoas aleatórias e não ordenada. O componente deve mostrar uma lista ordenada dos nomes em ordem alfabética em uma ul.

const OlaMundo = () => {
  return (
    <>
      <div className='olaMundo'>Olá, Mundo!!</div>
    </>
  );
};
export default OlaMundo;
